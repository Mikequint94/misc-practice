import React, { Component } from 'react';
import './App.css';
import FormContainer from './FormContainer';

class App extends Component {
  render() {
    return (
      <FormContainer />
    );
  }
}

export default App;
